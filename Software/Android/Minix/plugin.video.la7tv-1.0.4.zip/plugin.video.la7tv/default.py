# Version 1.0.4 (03/06/2014)
# LA7 TV
# Italian News Channel
# By K.Mantzaris
# kmanjaris@gmail.com
# http://SlaXBMC.blogspot.com
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#######################################################################
import sys,os,xbmc,urllib,urllib2,re,datetime,time,HTMLParser,xbmcplugin,xbmcgui,xbmcaddon
from urllib import urlretrieve
__settings__ = xbmcaddon.Addon(id='plugin.video.la7tv')
__language__ = __settings__.getLocalizedString
fanart = os.path.join(__settings__.getAddonInfo('path'),'fanart.jpg')
bGoBack=__settings__.getSetting("goback")
bSclist=__settings__.getSetting("sclist")


#LA7 TV Category Menu
def CATEGORY():
        #TODO: Find the way to tap into their web based live streaming content
        #VIDEOLINKS("http://www.la7.it/dirette-tv","LA7 Live",os.path.join(__settings__.getAddonInfo('path'),'resources','images','live.png'))
        req = urllib2.Request("http://www.la7.it/rivedila7/")
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link=normalize_link(link)
        block=re.compile('<div id="wrapper_canale_giorno"(.+?)<div id="content_guida_tv"').findall(link)
        match=re.compile('<a href="(.+?)">(.+?)"dateDay">(.+?)</div>(.+?)"dateMonth">(.+?)</div>(.+?)"dateRowWeek(.+?)>(.+?)</div>').findall(str(block[0]))
        for url,buffer1,aDate,buffer2,aMonth,buffer3,buffer4,aNameDate in reversed(match):
                addDir(aNameDate+" "+aDate+"/"+aMonth,"http://www.la7.it"+url,1,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
        addSetting('Settings...','plugin://plugin.video.la7tv',20,os.path.join(__settings__.getAddonInfo('path'),'resources','images','settings.png'))


#LA7 TV Video Index
def VIDEOINDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link=normalize_link(link)
        block=re.compile('<div id="content_guida_tv"(.+?)<div id="block-socials-module-socials-module-ft-timeline"').findall(link)
        reblock=re.compile('<div class="orario"(.+?)<div id="').findall(str(block[0]))
        for webisode in reblock:
                if not "CONTENUTO NON DISPONIBILE" in webisode:
                        match=re.compile('>(.+?)</div>(.+?)<img src="(.+?)"(.+?)<a href="(.+?)">(.+?)</a>(.+?)"titolo-replica clearfix">(.+?)</div>(.+?)"approfondisci">(.+?)</div>').findall(webisode)
                        for orario,buffer1,thumb,buffer2,url,name1,buffer3,name2,buffer4,name3 in match:
                                name1 = name1.strip()
                                name2 = name2.strip()
                                name3 = name3.strip()
                                if name1 == name2:
                                        if not "http" in url:
                                                if bSclist == "true":
                                                        VIDEOLINKS("http://www.la7.it"+url,orario+" "+name1+" ("+name3+")",thumb)
                                                else:
                                                        addDir(orario+" "+name1+" ("+name3+")","http://www.la7.it"+url,2,thumb)
                                        else:
                                                if bSclist == "true":
                                                        VIDEOLINKS(url,orario+" "+name1+" ("+name3+")",thumb)
                                                else:
                                                        addDir(orario+" "+name1+" ("+name3+")",url,2,thumb)
                                else:
                                        if not "http" in url:
                                                if bSclist == "true":
                                                        VIDEOLINKS("http://www.la7.it"+url,orario+" "+name2+" - "+name1+" ("+name3+")",thumb)
                                                else:
                                                        addDir(orario+" "+name2+" - "+name1+" ("+name3+")","http://www.la7.it"+url,2,thumb)
                                        else:
                                                if bSclist == "true":
                                                        VIDEOLINKS(url,orario+" "+name2+" - "+name1+" ("+name3+")",thumb)
                                                else:
                                                        addDir(orario+" "+name2+" - "+name1+" ("+name3+")",url,2,thumb)
        if bGoBack == "true":
                addSetting('<< [ Back ]','plugin://plugin.video.la7tv/',10,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))


def VIDEOLINKS(url,name,thumb):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link=normalize_link(link)
        match=re.compile('kWidget.embed(.+?)"wid":(.+?),(.+?)"uiconf_id":(.+?),(.+?)"cache_st":(.+?),(.+?)"entry_id":(.+?)}').findall(link)
        for buffer1,wid,buffer2,uiconf,buffer3,cache_st,buffer4,entry_id in match:
                wid = wid.replace('"','').strip()
                uiconf = uiconf.replace('"','').strip()
                cache_st = cache_st.replace('"','').strip()
                entry_id = entry_id.replace('"','').strip()
                req = urllib2.Request("http://kdam.iltrovatore.it/p/103/sp/10300/playManifest/entryId/"+entry_id+"/flavorId/")
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
                response = urllib2.urlopen(req)
                alink=response.read()
                response.close()
                alink=link=normalize_link(alink)
                getid=re.compile('<media url="(.+?)"').findall(alink)
                if bSclist == "true":
                        addLink(name,getid[0],thumb)
                else:
                        addLink(name,getid[0],os.path.join(__settings__.getAddonInfo('path'),'resources','images','video.png'))
        if bGoBack == "true" and bSclist == "false":
                addSetting('<< [ Back ]','plugin://plugin.video.la7tv/',10,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))


##def CalculateDate(curDate, DatePos, sDate):
##        if sDate == "true":
##                StartDate=datetime.datetime(*(time.strptime(curDate, '%m/%d/%Y')[0:6]))
##                vidDate=StartDate+datetime.timedelta(days=int(DatePos))
##                return " ("+vidDate.strftime("%d %b %Y")+")"
##        else:
##                return ""

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addLink(name,url,iconimage):
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def addSetting(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok 


def normalize_link(link):
        match=re.compile('charset=(.+?)"').findall(link)
        if not match:
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                return link
        elif match[0].upper() == "UTF-8":
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                return link
        else:
                link=link.replace('\t','').replace('\r\n','').replace('\n','').decode(match[0]).encode('utf-8')
                return link


def LoadSettings():
        __settings__.openSettings(sys.argv[ 0 ])
        bGoBack=__settings__.getSetting("goback")
        bSclist=__settings__.getSetting("sclist")


def PageBack():
        xbmc.executebuiltin( "XBMC.Action(Back)" )


params=get_params()
url=None
name=None
mode=None
thumb=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


if mode==None or url==None or len(url)<1:
        CATEGORY()
elif mode==1:
        VIDEOINDEX(url)
elif mode==2:
        VIDEOLINKS(url,name,thumb)
if mode==10:
	PageBack()
elif mode==20:
	LoadSettings()   

xbmcplugin.endOfDirectory(int(sys.argv[1]))
